RedditBot
=========

A simple Reddit bot in Python.

A software bot is a program that can interact with websites autonomously. They can be as simple or as complex as you want them to be.

The bot runs in the background and monitors a website. When it sees a change (like a post on Reddit), it can reply to it, upvote, or do any other task it was programmed to.


To learn how to build this bot, please see:

http://pythonforengineers.com/build-a-reddit-bot-part-1/
