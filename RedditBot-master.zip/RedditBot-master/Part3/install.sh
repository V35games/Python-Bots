sudo apt-get  update -y
sudo apt-get install python-pip -y
sudo apt-get install git -y

sudo pip install praw

git clone https://github.com/shantnu/RedditBot.git